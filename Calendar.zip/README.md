# Моят Ден — Kids Training Schedule App

A mobile-first, single-screen schedule app for a child athlete. No backend — all data is hardcoded.

## Files

| File | Purpose |
|------|---------|
| `Schedule.html` | The app — open this in a browser |
| `tweaks-panel.jsx` | In-page Tweaks UI (loaded by Schedule.html) |

## Features

- **Live countdown** to the next event (`MM:SS`), flips to red elapsed time once started
- **Auto-advance** — hero event advances at the halfway point to the next event
- **Готово ✓** button to manually mark an event done and jump to the next
- **Per-event checklists** — tap to check items; state is remembered per event
- **Per-event colours** — page and hero card background shift for each activity type
- **Dark mode** for Лека нощ (bedtime) to reduce eye strain

## Schedule

| Time  | Event                  |
|-------|------------------------|
| 6:30  | 🌅 Добро утро           |
| 7:30  | ⛸️ Лед с Албена        |
| 8:45  | 🥐 Закуска              |
| 10:30 | ⛸️ Лед със Стоян       |
| 11:45 | 💪 Суха със Стоян       |
| 13:00 | 🍝 Обяд                 |
| 15:00 | ⛸️ Лед с Андрей        |
| 16:30 | 🍎 Следобедна закуска   |
| 17:00 | 💪 Суха със Стоян       |
| 19:30 | 🥗 Вечеря               |
| 21:00 | 🌙 Лека нощ             |

## Checklists

- **Добро утро** — 🪥 Зъби · 👕 Дрехи · 🪮 Коса · 👟 Обуване
- **Лед** — ⛸️ Кънки · 🪢 Ластик · 💧 Вода
- **Суха** — 🎒 Чанта · 🌀 Постелка · 💧 Вода
- **Лека нощ** — 🪥 Зъби · 🚿 Душ · 🪮 Коса · 👕 Пижама

## Tweaks Panel

Open via the toolbar toggle. Controls:

- **Цвят** — accent colour for the Готово button and checklist checks (`ice` / `aurora` / `sunset`)
- **Събитие** (debug) — jump to any event regardless of real time
- **Таймер** (debug) — force countdown (`обратно`) or elapsed (`изминало`) display
